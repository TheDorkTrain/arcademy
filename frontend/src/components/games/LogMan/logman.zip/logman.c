#pragma export(LOGMAN)            

#pragma prolog(LOGMAN, main)
#pragma epilog(LOGMAN, main)

#include <metal/metal.h>
#include <metal/stddef.h>
#include <metal/stdlib.h>
#include <metal/string.h>

#define NUM_LINES 17
#define LINE_LEN 60

void LOGMAN(void) {
  struct WTO_Line {
    short len;
    short mcsflags;
    unsigned char message[LINE_LEN];
  };

  struct WTO_Line lines[NUM_LINES];
  int end_marker = 0;


  memset(lines, 0, sizeof(lines));

//   Copy and Paste each Step from gamepices.txt for each failed guess.
  
  char *wordgame[NUM_LINES] = {
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    "                                              ",
    // Words go below these lines
    "          _ _ _       _ _ _                   ",
    "                                              ",
    " Letters Guessed:                             ",
  };

  for (int i = 0; i < NUM_LINES; i++) {
    struct WTO_Line msg;
    memset(&msg, 0, sizeof(msg));
    
    strncpy((char*)msg.message, wordgame[i], LINE_LEN - 1);
    msg.len = (short)(strlen((char*)msg.message) + 4);
    msg.mcsflags = 0;

   void *msgptr = &msg;
    __asm(
      " LR  1,%0\n"
      " WTO MF=(E,(1))"
      :
      : "r"(msgptr)
      : "r0", "r1", "r14", "r15"
    );
  }
}