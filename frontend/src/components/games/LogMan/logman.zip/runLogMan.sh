xlc -g -qmetal -S '-Wc,longname,lp64,RENT' logman.c
as -g  -mgoff -mMX -aegimrsx -I CBC.SCCNSAM -o logman.o logman.s > logman.lstc
ld -e LOGMAN -S"//'CBC.SCCNOBJ'" -o ./logman.o
